echo Hej hej
echo tjenixen
echo testing testing